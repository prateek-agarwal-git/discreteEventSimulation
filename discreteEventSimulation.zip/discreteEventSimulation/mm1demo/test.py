#!/bin/env python3
A =list(map( float,input().rstrip().split()))
print(A)